CALCULPRO — CALCULATRICE SCIENTIFIQUE

1. Décompressez le ZIP.
2. Ouvrez index.html dans un navigateur pour utiliser la calculatrice.
3. Pour publier, téléversez index.html, style.css et script.js dans le même dossier sur votre hébergement.

Le script Google AdSense demandé est intégré dans la section <head> de index.html avec votre identifiant ca-pub-8902181246110181.
ATTENTION : ce script seul ne garantit pas l'affichage des publicités. Le domaine doit être accepté par AdSense et, selon la configuration, vous devrez activer les annonces automatiques ou ajouter des emplacements publicitaires. Les publicités peuvent ne pas s'afficher en local.
